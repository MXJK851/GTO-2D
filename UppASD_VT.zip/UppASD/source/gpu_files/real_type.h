#ifndef __REAL_TYPE_H__
#define __REAL_TYPE_H__

#ifdef SINGLE_PREC
typedef float  real;
#else
typedef double real;
#endif

#endif

